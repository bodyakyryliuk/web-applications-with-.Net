namespace lab9.Models;

public enum Category
{
    Books,
    Electronics,
    Home,
    Children,
    Clothes,
    Food,
    Health
}