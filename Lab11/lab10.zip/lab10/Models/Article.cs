using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using lab10.Models;

namespace lab10.Models;

public class Article
{
    [Key]
    public int Id { get; set; }
    [Required]
    [StringLength(100)]
    public string Name { get; set; }
    [Required]
    [Column(TypeName = "decimal(18,2)")]
    [Range(0, double.MaxValue, ErrorMessage = "Price must be a positive value.")]
    public double Price { get; set; }
    public string? Image { get; set; }
    [Required(ErrorMessage = "Category is required.")]
    public int CategoryId { get; set; }
    public Category Category { get; set; }
    
}