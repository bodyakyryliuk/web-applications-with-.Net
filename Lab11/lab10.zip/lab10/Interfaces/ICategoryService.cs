using lab10.DTO;
using lab10.Models;

namespace lab10.Interfaces;

public interface ICategoryService
{
    void CreateCategory(CategoryDto categoryDto);
    List<Category> GetAllCategories();
    Category GetCategoryById(int id);
    void UpdateCategoryById(int id, Category updatedCategory);
    void DeleteCategory(int id);

}