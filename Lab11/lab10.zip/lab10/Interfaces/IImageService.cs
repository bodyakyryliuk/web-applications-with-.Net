using SixLabors.ImageSharp;

namespace lab10.Interfaces;

public interface IImageService
{
    Task<Image> ResizeImageAsync(IFormFile image, int width, int height);
    Task<string> SaveImageAsync(IFormFile image);
}
