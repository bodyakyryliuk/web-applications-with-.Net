using lab10.Models;

namespace lab10.Interfaces;

public interface IShopService
{
    void AddToShoppingCart(int articleId);
    void IncreaseQuantity(int articleId);
    void DecreaseQuantity(int articleId);
    void Remove(int articleId);
    IEnumerable<Article> getCartArticles();
    double CalculateTotalCost();

}