using lab10.DTO;
using lab10.Models;

namespace lab10.Interfaces;

public interface IArticleService
{
    List<Article> GetAllArticles();
    List<Article> GetAllArticlesByCategory(Category category);
    Article GetArticleById(int id);
    void CreateArticle(ArticleDto articleDto);
    void UpdateArticleById(int id, Article updatedArticle);
    void DeleteArticle(int id);
}