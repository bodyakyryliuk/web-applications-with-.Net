using lab10.DTO;
using lab10.Interfaces;
using lab10.Models;
using lab10.Interfaces;

namespace lab10.Services;

public class CategoryService : ICategoryService
{
    private readonly MyDbContext _context;
    
    public CategoryService(MyDbContext context)
    {
        _context = context;
    }
    public void CreateCategory(CategoryDto categoryDto)
    {
        var category = new Category
        {
            Name = categoryDto.Name
        };
        
        _context.Categories.Add(category);
        _context.SaveChanges();
    }

    public List<Category> GetAllCategories()
    {
        return _context.Categories
            .ToList();
    }

    public Category GetCategoryById(int id)
    {
        return _context.Categories
            .FirstOrDefault(category => category.Id == id);
    }

    public void UpdateCategoryById(int id, Category updatedCategory)
    {
        var category = _context.Categories.Find(id);
        if (category == null)
        {
            throw new Exception("Category not found");
        }

        category.Name = updatedCategory.Name;
        _context.SaveChanges();
    }

    public void DeleteCategory(int id)
    {
        var category = _context.Categories.Find(id);
        if (category == null)
        {
            throw new Exception("Category not found");
        }
        
        var articlesInCategory = _context.Articles.Where(a => a.CategoryId == id).ToList();
        foreach (var article in articlesInCategory)
        {
            _context.Articles.Remove(article);
        }

        _context.Categories.Remove(category);
        _context.SaveChanges();
    }
}