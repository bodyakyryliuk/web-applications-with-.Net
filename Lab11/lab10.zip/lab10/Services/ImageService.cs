using System.Net.Mime;
using lab10.Interfaces;

namespace lab10.Services;

using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.Formats;

public class ImageService : IImageService
{
    private readonly string _imagesFolder;

    public ImageService(IWebHostEnvironment env)
    {
        _imagesFolder = Path.Combine(env.WebRootPath, "images");
    }

    public async Task<Image> ResizeImageAsync(IFormFile image, int width, int height)
    {
        using var imageStream = image.OpenReadStream();
        var imageResult = await Image.LoadAsync(imageStream);
        imageResult.Mutate(x => x.Resize(width, height));
        return imageResult;
    }
    
    public async Task<string> SaveImageAsync(IFormFile image)
    {
        var fileName = $"{Path.GetFileNameWithoutExtension(image.FileName)}_{DateTime.UtcNow:yyyyMMddHHmmssfff}{Path.GetExtension(image.FileName)}";
        var filePath = Path.Combine(_imagesFolder, fileName);

        using (var imageStream = image.OpenReadStream())
        using (var outputStream = new FileStream(filePath, FileMode.Create))
        {
            var imageResult = await Image.LoadAsync(imageStream);
            await imageResult.SaveAsJpegAsync(outputStream); 
        }

        return fileName;
    }

    
}
