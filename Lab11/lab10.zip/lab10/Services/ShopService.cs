using System.Text.Json;
using lab10.Interfaces;
using lab10.Models;

namespace lab10.Services;

public class ShopService : IShopService
{
    private const string ShoppingCartCookie = "ShoppingCart";
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IArticleService _articleService;

    public ShopService(IHttpContextAccessor httpContextAccessor, IArticleService articleService)
    {
        _httpContextAccessor = httpContextAccessor;
        _articleService = articleService;
    }
    
    public void AddToShoppingCart(int articleId)
    {
        var shoppingCart = GetShoppingCart();
        
        if (shoppingCart.ContainsKey(articleId))
        {
            shoppingCart[articleId]++;
        }
        else
        {
            shoppingCart[articleId] = 1;
        }
        
        UpdateShoppingCartCookie(shoppingCart);
        
    }

    public void IncreaseQuantity(int articleId)
    {
        var shoppingCart = GetShoppingCart();
        
        if (shoppingCart.ContainsKey(articleId))
        {
            shoppingCart[articleId]++;
        }
        UpdateShoppingCartCookie(shoppingCart);
    }

    public void DecreaseQuantity(int articleId)
    {
        var shoppingCart = GetShoppingCart();
        
        if (shoppingCart.ContainsKey(articleId))
        {
            shoppingCart[articleId]--;
        }
        UpdateShoppingCartCookie(shoppingCart);
    }

    public void Remove(int articleId)
    {
        var shoppingCart = GetShoppingCart();
        
        if (shoppingCart.ContainsKey(articleId))
        {
            shoppingCart.Remove(articleId);
        }
        UpdateShoppingCartCookie(shoppingCart);
    }

    public IEnumerable<Article> getCartArticles()
    {
        var allArticles = _articleService.GetAllArticles();
        var shoppingCart = GetShoppingCart();

        // Use LINQ to filter articles
        var cartArticles = allArticles.Where(article => shoppingCart.ContainsKey(article.Id)).ToList();

        return cartArticles;
    }

    public double CalculateTotalCost()
    {
        var shoppingCart = GetShoppingCart();
        double total = 0;
        foreach (var id in shoppingCart.Keys)
        {
            total += _articleService.GetArticleById(id).Price * shoppingCart.GetValueOrDefault(id);
        }

        return total;
    }


    private Dictionary<int, int> GetShoppingCart()
    {
        // Get the current shopping cart from the cookie
        var shoppingCartCookie = _httpContextAccessor.HttpContext.Request.Cookies[ShoppingCartCookie];
        Dictionary<int, int> shoppingCart;

        if (!string.IsNullOrEmpty(shoppingCartCookie))
        {
            // Deserialize the cookie data
            shoppingCart = JsonSerializer.Deserialize<Dictionary<int, int>>(shoppingCartCookie);
        } else
        {
            // Initialize a new cart
            shoppingCart = new Dictionary<int, int>();
        }

        RemoveNonExistingArticle(shoppingCart);

        return shoppingCart;
    }

    private void RemoveNonExistingArticle(Dictionary<int, int> shoppingCart)
    {
        List<int> nonExistingArticleIds = new List<int>();

        foreach (var id in shoppingCart.Keys)
        {
            if (_articleService.GetArticleById(id) == null)
            {
                nonExistingArticleIds.Add(id);
            }
        }

        foreach (var id in nonExistingArticleIds)
        {
            shoppingCart.Remove(id);
        }
    }
    
    private void UpdateShoppingCartCookie(Dictionary<int, int> shoppingCart)
    {
        var updatedCartJson = JsonSerializer.Serialize(shoppingCart);
        var cookieOptions = new CookieOptions
        {
            Expires = DateTime.Now.AddDays(30),
            HttpOnly = true,
            Secure = true
        };

        _httpContextAccessor.HttpContext.Response.Cookies.Append(ShoppingCartCookie, updatedCartJson, cookieOptions);
    }

}