using lab10.DTO;
using lab10.Interfaces;
using lab10.Models;
using Microsoft.EntityFrameworkCore;

namespace lab10.Services;

public class ArticlesService : IArticleService
{
    private readonly MyDbContext _context;

    public ArticlesService(MyDbContext context)
    {
        _context = context;
    }

    public List<Article> GetAllArticles()
    {
        return _context.Articles
            .Include(article => article.Category) // Include the Category data
            .ToList();
    }

    public List<Article> GetAllArticlesByCategory(Category category)
    {
        return _context.Articles
            .Include(article => article.Category) // Include the Category data
            .Where(article => article.Category == category)
            .ToList();    
    }

    public Article GetArticleById(int id)
    {
        return _context.Articles
            .Include(article => article.Category) // Include the Category data
            .FirstOrDefault(article => article.Id == id);
    }

    public void CreateArticle(ArticleDto articleDto)
    {
        var article = new Article
        {
            Name = articleDto.Name,
            Price = articleDto.Price,
            Image = articleDto.ImagePath,
            CategoryId = articleDto.CategoryId
        };

        _context.Articles.Add(article);
        _context.SaveChanges();
    }
    
    public void UpdateArticleById(int id, Article updatedArticle)
    {
        var article = _context.Articles.Find(id);
        if (article == null)
        {
            throw new Exception("Article not found");
        }

        article.Name = updatedArticle.Name;
        article.Price = updatedArticle.Price;
        article.Image = updatedArticle.Image;
        article.CategoryId = updatedArticle.CategoryId;

        _context.SaveChanges();
    }

    public void DeleteArticle(int id)
    {
        var article = _context.Articles.Find(id);
        if (article == null)
        {
            throw new Exception("Article not found");
        }
        
        deleteImage(article);
        _context.Articles.Remove(article);
        _context.SaveChanges();
    }

    private void deleteImage(Article article)
    {
        if (article.Image == "default.jpg")
            return;
        
        string path = "images/" + article.Image;
        if (!string.IsNullOrWhiteSpace(path))
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", path);
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }
        }
    }
}