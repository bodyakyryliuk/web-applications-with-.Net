using System.ComponentModel.DataAnnotations;

namespace lab10.DTO;

public class CategoryDto
{
    [Required(ErrorMessage = "Name is required.")]
    public string Name { get; set; }
}