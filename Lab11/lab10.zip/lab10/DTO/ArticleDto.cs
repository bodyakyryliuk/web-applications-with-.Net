using System.ComponentModel.DataAnnotations;
using lab10.Models;

namespace lab10.DTO;

public class ArticleDto
{
    [Required(ErrorMessage = "Name is required.")]
    [StringLength(30, ErrorMessage = "Name cannot be longer than 100 characters.")]
    public string Name { get; set; }
    
    [Required(ErrorMessage = "Price is required.")]
    public double Price { get; set; }
    
    public IFormFile? Image { get; set; }
    
    public string ImagePath { get; set; }
    
    [Required(ErrorMessage = "Category is required.")]
    public int CategoryId { get; set; }
}