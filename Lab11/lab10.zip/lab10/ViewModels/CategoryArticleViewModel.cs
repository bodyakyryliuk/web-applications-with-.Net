using lab10.Models;

namespace lab10.ViewModels;

public class CategoryArticleViewModel
{
    public IEnumerable<Category> Categories { get; set; }
    public IEnumerable<Article> Articles { get; set; }
    public int CurrentCategoryId { get; set; }
}
