using lab10.Models;

namespace lab10.ViewModels;

public class ShoppingCartViewModel
{
    public IEnumerable<Article> Articles { get; set; }
    public Dictionary<int, int> ArticleQuantities { get; set; }
    public double TotalCost { get; set; }

}