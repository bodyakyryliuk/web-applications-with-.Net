using lab10.DTO;
using lab10.Interfaces;
using lab10.Models;
using lab10.Interfaces;
using lab10.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace lab10.Controllers;

[Route("[controller]")]
public class ArticlesController : Controller
{
    private readonly IArticleService _articleService;
    private readonly ICategoryService _categoryService;
    private readonly IImageService _imageService;

    public ArticlesController(IArticleService articleService, ICategoryService categoryService, IImageService imageService)
    {
        this._articleService = articleService;
        this._categoryService = categoryService;
        this._imageService = imageService;
    }

    [HttpGet("")]
    public IActionResult Index()
    {
        List<Article> articles = _articleService.GetAllArticles();
        
        return View("~/Views/Articles/Index.cshtml",articles);
    }
    
    [HttpGet("details/{id}")]
    public IActionResult Details(int id)
    {
        var article = _articleService.GetArticleById(id);

        return View(article);
    }
    
    [HttpGet("create")]
    public IActionResult Create()
    {
        ViewBag.Categories = _categoryService.GetAllCategories()
            .Select(c => new SelectListItem 
            {
                Value = c.Id.ToString(),
                Text = c.Name
            }).ToList();
        
        return View();
    }


    [HttpPost("create")]
    public async Task<IActionResult> Create(ArticleDto articleDto)
    {
        ModelState.Remove("ImagePath");

        if (ModelState.IsValid)
        {
            if (articleDto.Image != null && articleDto.Image.Length > 0)
            {
                articleDto.ImagePath = await _imageService.SaveImageAsync(articleDto.Image);
            }
            else
            {
                articleDto.ImagePath = "default.jpg";
            }

            _articleService.CreateArticle(articleDto);

            // Redirect to the index action to show the list of articles
            return RedirectToAction(nameof(Index));
        }

        ViewBag.Categories = _categoryService.GetAllCategories()
            .Select(c => new SelectListItem 
            {
                Value = c.Id.ToString(),
                Text = c.Name
            }).ToList();

        return View(articleDto);
    }
    
    [HttpGet("edit/{id}")]
    public ActionResult Edit(int id)
    {
        var article = _articleService.GetArticleById(id);
        ViewBag.Categories = _categoryService.GetAllCategories()
            .Select(c => new SelectListItem 
            {
                Value = c.Id.ToString(),
                Text = c.Name
            }).ToList();

        return View(article);
    }

    [HttpPost("edit/{id}")]
    public ActionResult Edit(Article updatedArticle)
    {
        ModelState.Remove("Category");
        if (ModelState.IsValid)
        {
            _articleService.UpdateArticleById(updatedArticle.Id, updatedArticle);
            return RedirectToAction("Index"); 
        }
        
        ViewBag.Categories = _categoryService.GetAllCategories()
            .Select(c => new SelectListItem { Value = c.Id.ToString(), Text = c.Name })
            .ToList();
        return View(updatedArticle);
    }

    [HttpPost("delete")]
    public IActionResult Delete(int id)
    {
        _articleService.DeleteArticle(id);

        return Index();
    }
}