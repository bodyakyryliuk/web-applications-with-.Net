using System.Text.Json;
using lab10.Interfaces;
using lab10.Models;
using lab10.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace lab10.Controllers;

[Route("[controller]")]
public class ShopController: Controller
{
    private readonly IArticleService _articleService;
    private readonly ICategoryService _categoryService;
    private readonly IShopService _shopService;
    public ShopController(IArticleService articleService, ICategoryService categoryService, IShopService shopService)
    {
        _articleService = articleService;
        _categoryService = categoryService;
        _shopService = shopService;
    }

    [HttpGet("")]
    public IActionResult Index(int categoryId)
    {
        Category category = _categoryService.GetCategoryById(categoryId);
        var viewModel = new CategoryArticleViewModel
        {
            Categories = _categoryService.GetAllCategories(),
            Articles = _articleService.GetAllArticlesByCategory(category),
            CurrentCategoryId = categoryId
        };

        return View(viewModel);
    }
    
    [HttpGet("Cart")]
    public IActionResult Cart()
    {
        var viewModel = new ShoppingCartViewModel()
        {
            Articles = _shopService.getCartArticles(),
            ArticleQuantities = new Dictionary<int, int>(),
            TotalCost = _shopService.CalculateTotalCost()
        };

        string shoppingCartCookie = Request.Cookies["ShoppingCart"];
        if (!string.IsNullOrEmpty(shoppingCartCookie))
        {
            viewModel.ArticleQuantities = JsonSerializer.Deserialize<Dictionary<int, int>>(shoppingCartCookie);
        }

        return View(viewModel);
    }

    [HttpPost("AddToCart")]
    public IActionResult AddToShoppingCart(int articleId, int categoryId)
    {
        _shopService.AddToShoppingCart(articleId);
        return RedirectToAction("Index", new { categoryId });
    }
    
    [HttpPost("IncreaseQuantity")]
    public IActionResult IncreaseQuantity(int articleId)
    {
        _shopService.IncreaseQuantity(articleId);
        return RedirectToAction("Cart");
    }
    
    [HttpPost("DecreaseQuantity")]
    public IActionResult DecreaseQuantity(int articleId)
    {
        _shopService.DecreaseQuantity(articleId);
        return RedirectToAction("Cart");
    }
    
    [HttpPost("Remove")]
    public IActionResult Remove(int articleId)
    {
        _shopService.Remove(articleId);
        return RedirectToAction("Cart");
    }
    
}