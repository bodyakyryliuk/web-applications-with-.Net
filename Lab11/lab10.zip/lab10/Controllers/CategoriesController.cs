using Microsoft.AspNetCore.Mvc;
using lab10.DTO;
using lab10.Models;
using lab10.Services;
using lab10.Interfaces;
using lab10.Interfaces;

[Route("[controller]")]
public class CategoriesController : Controller
{
    private readonly ICategoryService _categoryService;

    public CategoriesController(ICategoryService categoryService)
    {
        _categoryService = categoryService;
    }

    [HttpGet("")]
    public IActionResult Index()
    {
        var categories = _categoryService.GetAllCategories();
        return View(categories);
    }

    [HttpGet("create")]
    public IActionResult Create()
    {
        return View();
    }

    [HttpPost("create")]
    [ValidateAntiForgeryToken]
    public IActionResult Create(CategoryDto categoryDto)
    {
        if (ModelState.IsValid)
        {
            _categoryService.CreateCategory(categoryDto);
            return RedirectToAction(nameof(Index));
        }

        return View(categoryDto);
    }

    [HttpPost]
    public ActionResult Edit(Category updatedCategory)
    {
        if (ModelState.IsValid)
        {
            _categoryService.UpdateCategoryById(updatedCategory.Id, updatedCategory);
            return RedirectToAction("Index"); // Redirect to the list view
        }
        return View(updatedCategory);
    }


    [HttpPost("delete")]
    public IActionResult Delete(int id)
    {
        _categoryService.DeleteCategory(id);

        return RedirectToAction(nameof(Index));
    }
}
