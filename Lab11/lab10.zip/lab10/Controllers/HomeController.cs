using System.Diagnostics;
using lab10.Interfaces;
using Microsoft.AspNetCore.Mvc;
using lab10.Models;
using lab10.Interfaces;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace lab10.Controllers;

public class HomeController : Controller
{
    private readonly ICategoryService _categoryService;
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger, ICategoryService categoryService)
    {
        _logger = logger;
        _categoryService = categoryService;
    }

    public IActionResult Index()
    {
        ViewBag.Categories = _categoryService.GetAllCategories()
            .Select(c => new SelectListItem 
            {
                Value = c.Id.ToString(),
                Text = c.Name
            }).ToList();
        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}