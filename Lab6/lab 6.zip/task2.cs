namespace lab_6;

public class task2
{
    public static void Main()
    {
        var @class = "This is string class";
        Console.WriteLine(@class);
    }
}