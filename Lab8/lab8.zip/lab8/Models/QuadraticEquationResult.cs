namespace lab8.Models;

public class QuadraticEquationResult
{
    public double? Root1 { get; set; }
    public double? Root2 { get; set; }
    public string Message { get; set; }
}